        // Array de músicas
        const songs = [
          {
            title: "okita souji",
            artist: "Anirap",
            src: "♪ Okita Souji _ Criança X Demônio _ AniRap(M4A_128K).m4a"
          },
          {
            title: "Maison",
            artist: "Emilo Piano ft. Lucie",
            src: "Emilio Piano ft. Lucie - Maison(MP3_160K).mp3"
          },
          {
            title: "Rock N Roll",
            artist: "Xrootz",
            src: "_Xrootz CL x Lz - Rock N_ Roll ft XIXO 503 (Letra)(MP3_160K).mp3"
          }
        ];

        // Elementos do DOM
        const coverImage = document.getElementById('cover-image');
        const songTitle = document.getElementById('song-title');
        const songArtist = document.getElementById('song-artist');
        const progress = document.getElementById('progress');
        const progressContainer = document.getElementById('progress-container');
        const currentTimeEl = document.getElementById('current-time');
        const durationEl = document.getElementById('duration');
        const playBtn = document.getElementById('play-btn');
        const prevBtn = document.getElementById('prev-btn');
        const nextBtn = document.getElementById('next-btn');
        const volumeSlider = document.getElementById('volume-slider');
        const musicPlayer = document.querySelector('.music-player');

        // Objeto de áudio
        const audio = new Audio();

        // Estado do player
        let isPlaying = false;
        let currentSongIndex = 0;

        // Inicializa o player com a primeira música
        function loadSong(song) {
            songTitle.textContent = song.title;
            songArtist.textContent = song.artist;
            coverImage.src = song.cover;
            audio.src = song.src;
        }

        // Toca a música
        function playSong() {
            isPlaying = true;
            playBtn.innerHTML = '⏸';
            musicPlayer.classList.add('playing');
            audio.play();
        }

        // Pausa a música
        function pauseSong() {
            isPlaying = false;
            playBtn.innerHTML = '▶';
            musicPlayer.classList.remove('playing');
            audio.pause();
        }

        // Música anterior
        function prevSong() {
            currentSongIndex--;
            if (currentSongIndex < 0) {
                currentSongIndex = songs.length - 1;
            }
            loadSong(songs[currentSongIndex]);
            if (isPlaying) {
                playSong();
            }
        }

        // Próxima música
        function nextSong() {
            currentSongIndex++;
            if (currentSongIndex > songs.length - 1) {
                currentSongIndex = 0;
            }
            loadSong(songs[currentSongIndex]);
            if (isPlaying) {
                playSong();
            }
        }

        // Atualiza a barra de progresso
        function updateProgress(e) {
            if (isPlaying) {
                const { duration, currentTime } = e.srcElement;
                const progressPercent = (currentTime / duration) * 100;
                progress.style.width = `${progressPercent}%`;
                
                // Formatação do tempo
                const durationMinutes = Math.floor(duration / 60);
                let durationSeconds = Math.floor(duration % 60);
                if (durationSeconds < 10) {
                    durationSeconds = `0${durationSeconds}`;
                }
                
                // Evita NaN
                if (durationSeconds) {
                    durationEl.textContent = `${durationMinutes}:${durationSeconds}`;
                }
                
                const currentMinutes = Math.floor(currentTime / 60);
                let currentSeconds = Math.floor(currentTime % 60);
                if (currentSeconds < 10) {
                    currentSeconds = `0${currentSeconds}`;
                }
                currentTimeEl.textContent = `${currentMinutes}:${currentSeconds}`;
            }
        }

        // Define o progresso da música ao clicar na barra
        function setProgress(e) {
            const width = this.clientWidth;
            const clickX = e.offsetX;
            const duration = audio.duration;
            audio.currentTime = (clickX / width) * duration;
        }

        // Event Listeners
        playBtn.addEventListener('click', () => {
            isPlaying ? pauseSong() : playSong();
        });

        prevBtn.addEventListener('click', prevSong);
        nextBtn.addEventListener('click', nextSong);

        audio.addEventListener('timeupdate', updateProgress);
        audio.addEventListener('ended', nextSong);
        
        progressContainer.addEventListener('click', setProgress);

        volumeSlider.addEventListener('input', (e) => {
            audio.volume = e.target.value / 100;
        });

        // Inicializa
        loadSong(songs[currentSongIndex]);
        audio.volume = volumeSlider.value / 100;